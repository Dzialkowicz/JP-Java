import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.*;

/**
 * Created by Kuba Sanecki on 26.11.2016.
 */
class ManageOrders {


	static  String [] namesOfFlowers =  {"Roza","Tulipan", "Stokrotka", "Kaktus", "Lilia", "Kwiatek"};







}
