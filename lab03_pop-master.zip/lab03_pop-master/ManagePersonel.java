/**
 * Created by Kuba Sanecki on 26.11.2016.
 */
public class ManagePersonel {
}
